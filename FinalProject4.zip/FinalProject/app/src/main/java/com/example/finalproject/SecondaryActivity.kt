import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SecondaryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_secondary)

        // Receive information from the Entry Point Activity using an intent
        val intent = intent
        val receivedInfo = intent.getStringExtra("taskDetails")

        // Utilize the received information to enhance the functionality
        val detailsTextView: TextView = findViewById(R.id.detailsTextView)
        detailsTextView.text = "Task Details:\n$receivedInfo"

        // Additional TextViews for more information
        val descriptionTextView: TextView = findViewById(R.id.descriptionTextView)
        descriptionTextView.text = "Description: Lorem ipsum dolor sit amet, consectetur adipiscing elit."

        val dueDateTextView: TextView = findViewById(R.id.dueDateTextView)
        dueDateTextView.text = "Due Date: December 31, 2023"

        // Button to mark the task as complete
        val completeButton: Button = findViewById(R.id.completeButton)
        completeButton.setOnClickListener {
            // Perform actions when the user marks the task as complete
            detailsTextView.append("\nStatus: Complete")
            completeButton.visibility = View.GONE // Hide the button after completion (optional)
        }

        // Back Button to navigate back to the previous activity
        val backButton: Button = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            finish() // Close the current activity and go back to the previous one
        }
    }
}
