import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val taskList = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Display tasks in a ListView
        val listView: ListView = findViewById(R.id.listView)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, taskList)
        listView.adapter = adapter

        // Set item click listener to view task details
        listView.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            val selectedTask = taskList[position]
            // Start another activity to view task details (replace with your TaskDetailsActivity)
            val intent = Intent(this, TaskDetailsActivity::class.java)
            intent.putExtra("taskDetails", selectedTask)
            startActivity(intent)
        }

        // Button to add new tasks
        val addButton: Button = findViewById(R.id.addButton)
        addButton.setOnClickListener {
            showAddTaskDialog()
        }

        // Button to switch to HelpActivity
        val helpButton: Button = findViewById(R.id.helpButton)
        helpButton.setOnClickListener {
            val intent = Intent(this, HelpActivity::class.java)
            startActivity(intent)
        }
    }

    private fun showAddTaskDialog() {
        val inputEditText = EditText(this)
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Add New Task")
            .setMessage("Enter task details:")
            .setView(inputEditText)
            .setPositiveButton("Add") { _, _ ->
                val newTask = inputEditText.text.toString()
                if (newTask.isNotBlank()) {
                    taskList.add(newTask)
                    (findViewById<ListView>(R.id.listView).adapter as ArrayAdapter<*>).notifyDataSetChanged()
                }
            }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()
    }
}
