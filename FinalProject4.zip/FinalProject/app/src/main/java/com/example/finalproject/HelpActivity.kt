// Inside HelpActivity.kt

// After setting the content view
val navigationSpinner: Spinner = findViewById(R.id.navigationSpinner)
val navigationOptions = arrayOf("Main", "Preferences", "Secondary")
val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, navigationOptions)
adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
navigationSpinner.adapter = adapter

// Handle item selection
navigationSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        when (position) {
            0 -> {
                // Navigate to MainActivity
                val intent = Intent(this@HelpActivity, MainActivity::class.java)
                startActivity(intent)
            }
            1 -> {
                // Navigate to PreferencesActivity
                val intent = Intent(this@HelpActivity, PreferencesActivity::class.java)
                startActivity(intent)
            }
            2 -> {
                // Navigate to SecondaryActivity
                val intent = Intent(this@HelpActivity, SecondaryActivity::class.java)
                startActivity(intent)
            }
        }
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {
        // Do nothing
    }
}

